<body>
    <h1>ひと言掲示板</h1>
    <div style="text-align: right;"><a href=http://[::1]/board/index.php/admin/login>管理者画面へ</a></div>
    <form action="<?= base_url("bbs/add_bbs") ?>" method="post">
        <div>
            <?php if (!empty($success_message)): ?>
                <p class="success_message">
                    ・<?= html_escape($success_message) ?>
                </p>
            <?php endif; ?>
            <?php if (!empty($error_message)): ?>
            <ul class="error_message">
                <?php foreach ($error_message as $message): ?>
                    <li>・<?= html_escape($message) ?></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <p class="text-confirm"><span class="blink">以下の投稿を登録します。<br>よろしければ[書き込む]ボタンを押してください。</span></p><br>
            <label for="view_name">表示名</label>
            <!-- Add to session -->
            <input id="view_name" type="text" name="view_name" value="<?php if( !empty($_SESSION['view_name']) ){ echo $_SESSION['view_name']; } ?>">
        </div>
        <div>
            <label for="message">ひと言メッセージ</label>
            <textarea id="message" name="message"></textarea>
        </div>
        <input type="submit" name="btn_submit" value="書き込む">
    </form>
    <hr>
    <section>
    <!-- ここに投稿されたメッセージを表示する -->
        <?php if (!empty($message_array)): ?>
            <?php foreach( $message_array as $value ): ?>
            <article>
                <div class="info">
                    <h2><?= html_escape($value['view_name']) ?></h2>
                    <time><?= date('Y年m月d日 H:i', strtotime($value['post_date'])); ?></time>
                </div>
                <p><?= nl2br(html_escape($value['message'])); ?></p>
            </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
</body>
</html>