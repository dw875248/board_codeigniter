<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bbs extends CI_Controller
{
    public function __construct()
    {
        // CI_Model constructor の呼び出しを行う
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Bbs_model');
        $this->load->helper('url');
        $this->load->library('form_validation');
        date_default_timezone_set('Asia/Tokyo');
    }

     /**
      * 掲示板ページを出力する
      *
      * @return void
      */
    public function index()
    {
        $data = null;
        $data['message_array'] = $this->Bbs_model->fetch_all_rows();

        if (!empty($_SESSION['success_message'])) {
            $data['success_message'] = $_SESSION['success_message'];
            unset($_SESSION['success_message']);
        }
        if (!empty($_SESSION['error_message'])) {
            $data['error_message'] = $_SESSION['error_message'];
            unset($_SESSION['error_message']);
        }
        
        $this->load->view('header_view');
        $this->load->view('bbs_view', $data);

    }

     /**
     * httpリクエストのパラメータの正当性を検証する
     * 
     * @return void
     */
    private function request_validation() {
        $config = [
            [
                'field' => 'view_name',
                'label' => '表示名',
                'rules' => 'required',
                'errors' => [
                    'required' => '%sを入力してください。'
                ]
            ],
            [
                'field' => 'message',
                'label' => 'ひと言メッセージ',
                'rules' => 'required|max_length[100]',
                'errors' => [
                    'required' => '%sを入力してください。',
                    'max_length[100]' => '%sは１００文字までの入力になります。',
               ]
            ]
        ];
        $this->form_validation->set_rules($config);
        return $this->form_validation->run();
    }

    /**
     * POSTされてきたデータをDBにinsertする
     *
     * @return void
     */
    public function add_bbs()
    {
        if (!$this->request_validation()) {
            $errors = $this->form_validation->error_array();
            $_SESSION['error_message'] = $errors;
            redirect();
        }

        $name = $this->input->post('view_name', true);
        $message = $this->input->post('message', true);        

        $data = [
            'view_name' => $name,
            'message' => $message,
            'post_date' => date("Y-m-d H:i:s")
        ];

        if ($this->Bbs_model->insert_row($data)) {
            $_SESSION['success_message'] = 'メッセージを書き込みました。';
            /* Add to session */
            $_SESSION['view_name'] = $name;
        } else {
            $_SESSION['error_message'] = '登録に失敗しました。';
        }
            redirect();
        
    }
    
}